#!/usr/bin/env bash
# Run INSIDE the inference container. First argument must be an absolute output path.
# Usage: bash run_hccl_logged.sh /tmp/hccl_env1_48 /path/start_48.sh [script args]
# Optional second pass: HCCL_DIAG_PG_PROBE=1 bash run_hccl_logged.sh ...
# Does not change HCCL expansion/algorithm settings, CPU affinity or library paths.
set -euo pipefail
if [[ $# -lt 2 || "$1" != /* ]]; then
  echo 'Usage: bash run_hccl_logged.sh /absolute/output /path/start_48.sh [args]' >&2
  exit 2
fi
diag_out=$1
diag_start=$2
shift 2
diag_here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
mkdir -p -- "$diag_out"
diag_out=$(cd -- "$diag_out" && pwd)
if [[ -e "$diag_out/startup.log" ]]; then
  echo 'startup.log already exists; use a new output directory.' >&2
  exit 2
fi
[[ -f "$diag_start" ]] || { echo 'Startup script not found.' >&2; exit 2; }
cp -- "$diag_start" "$diag_out/start_script.txt"
mkdir -p -- "$diag_out/plog"
export ASCEND_PROCESS_LOG_PATH="$diag_out/plog"
export ASCEND_GLOBAL_LOG_LEVEL=3
export ASCEND_MODULE_LOG_LEVEL=HCCL=0
export ASCEND_SLOG_PRINT_TO_STDOUT=0
if [[ ${HCCL_DIAG_PG_PROBE:-0} == 1 ]]; then
  # Do not silently shadow the environment's own sitecustomize.
  if python3 -c 'import importlib.util, sys; sys.exit(0 if importlib.util.find_spec("sitecustomize") is None else 1)'; then
    mkdir -p -- "$diag_out/pg"
    export HCCL_DIAG_PG_DIR="$diag_out/pg"
    export PYTHONPATH="$diag_here/pg_probe${PYTHONPATH:+:$PYTHONPATH}"
  else
    echo 'Existing sitecustomize detected; run without HCCL_DIAG_PG_PROBE or inspect the conflict.' >&2
    exit 2
  fi
fi
printf 'UTC=%s\nASCEND_PROCESS_LOG_PATH=%s\nASCEND_MODULE_LOG_LEVEL=%s\nPG_PROBE=%s\n' \
  "$(date -u +%FT%TZ)" "$ASCEND_PROCESS_LOG_PATH" "$ASCEND_MODULE_LOG_LEVEL" "${HCCL_DIAG_PG_PROBE:-0}" > "$diag_out/capture_settings.txt"
set +e
bash "$diag_start" "$@" 2>&1 | tee "$diag_out/startup.log"
diag_codes=("${PIPESTATUS[@]}")
printf 'startup_exit=%s\ntee_exit=%s\n' "${diag_codes[0]}" "${diag_codes[1]}" > "$diag_out/exit_status.txt"
if [[ ${diag_codes[1]} -ne 0 ]]; then
  exit "${diag_codes[1]}"
fi
exit "${diag_codes[0]}"
