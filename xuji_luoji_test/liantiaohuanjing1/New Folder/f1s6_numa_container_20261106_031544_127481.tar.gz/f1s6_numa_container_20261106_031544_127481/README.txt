Read-only evidence; no VM or service configuration changed.
CPU sample is a short interval, not capacity proof. ps pcpu is lifetime-average.
Unpinned CPUs can still run host work, QEMU helpers and IRQs.
PCI NUMA -1 means unknown; do not substitute node0.
collector_status is this diagnostic process, not a vLLM worker.
processes/ contains worker or QEMU thread masks and cgroup limits when visible.
Live XML and inactive XML can differ. Unsupported read commands are recorded.
Run host collection during representative load; collect again after deployment.
