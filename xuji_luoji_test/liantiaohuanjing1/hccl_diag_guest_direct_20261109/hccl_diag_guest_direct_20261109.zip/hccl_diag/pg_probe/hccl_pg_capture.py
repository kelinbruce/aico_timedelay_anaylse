"""Record Python process-group arguments without changing them.

This cannot observe direct C++ communicator creation or HCCL's final native
selection. Pair it with HCCL debug logs and actual worker library hashes.
"""
import functools
import importlib.abc
import importlib.machinery
import inspect
import json
import os
from pathlib import Path
import sys
import time
import traceback


def safe(value, depth=0):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if depth > 5:
        return "<depth limit>"
    if isinstance(value, dict):
        return {str(k): safe(v, depth + 1) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe(v, depth + 1) for v in value]
    return str(value)


def options(value):
    if value is None:
        return None
    fields = {"python_type": type(value).__module__ + "." + type(value).__name__}
    for key in ("hccl_config", "is_high_priority_stream", "backend", "global_ranks_in_group", "group_id", "timeout", "_timeout"):
        try:
            fields[key] = safe(getattr(value, key))
        except AttributeError:
            pass
        except Exception as exc:
            fields[key] = {"read_error": str(exc)}
    return fields


def emit(record):
    try:
        directory = Path(os.environ["HCCL_DIAG_PG_DIR"])
        directory.mkdir(parents=True, exist_ok=True)
        record.update(pid=os.getpid(), time_ns=time.time_ns())
        with (directory / (str(os.getpid()) + ".jsonl")).open("a") as stream:
            stream.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception as exc:
        print("HCCL PG diagnostic write failed: " + str(exc), file=sys.stderr)


def wrap(fn, name):
    if getattr(fn, "_hccl_diag_wrapped", False):
        return fn
    @functools.wraps(fn)
    def recorded(*args, **kwargs):
        call_id = str(os.getpid()) + ":" + str(time.time_ns())
        try:
            bound = inspect.signature(fn).bind_partial(*args, **kwargs).arguments
            fields = {k: safe(bound[k]) for k in ("backend", "rank", "world_size", "ranks", "group_desc", "use_local_synchronization", "timeout") if k in bound}
            fields["pg_options_argument_present"] = "pg_options" in bound
            fields["pg_options"] = options(bound.get("pg_options"))
            fields["environment_at_call"] = {k: v for k, v in os.environ.items() if k.startswith("HCCL_") or k in ("RANK", "LOCAL_RANK", "WORLD_SIZE", "VLLM_BATCH_INVARIANT", "ASCEND_RT_VISIBLE_DEVICES")}
            torch = sys.modules.get("torch")
            getter = getattr(torch, "are_deterministic_algorithms_enabled", None)
            fields["torch_deterministic_algorithms"] = bool(getter()) if getter else None
            fields["caller"] = [{"file": f.filename, "line": f.lineno, "function": f.name} for f in traceback.extract_stack(limit=7)[:-1]]
            emit({"event": "before", "api": name, "call_id": call_id, **fields})
        except Exception as exc:
            emit({"event": "inspection_error", "api": name, "call_id": call_id, "error": str(exc)})
        try:
            result = fn(*args, **kwargs)
        except BaseException as exc:
            emit({"event": "call_error", "api": name, "call_id": call_id, "error_type": type(exc).__name__})
            raise
        try:
            group = result
            if name == "init_process_group" and result is None:
                group = getattr(getattr(sys.modules.get("torch.distributed"), "group", None), "WORLD", None)
            emit({"event": "after", "api": name, "call_id": call_id, "exposed_group_options": options(getattr(group, "options", None))})
        except Exception as exc:
            emit({"event": "inspection_error", "api": name, "call_id": call_id, "error": str(exc)})
        return result
    recorded._hccl_diag_wrapped = True
    return recorded


def patch(module):
    c10d = sys.modules.get("torch.distributed.distributed_c10d")
    for name in ("init_process_group", "new_group"):
        original = getattr(module, name, None)
        if original is None:
            continue
        wrapped = wrap(original, name)
        setattr(module, name, wrapped)
        if c10d is not None and getattr(c10d, name, None) is original:
            setattr(c10d, name, wrapped)
    emit({"event": "hook_installed", "module": module.__name__})


class Loader(importlib.abc.Loader):
    def __init__(self, original):
        self.original = original
    def create_module(self, spec):
        method = getattr(self.original, "create_module", None)
        return method(spec) if method else None
    def exec_module(self, module):
        self.original.exec_module(module)
        patch(module)
    def __getattr__(self, name):
        return getattr(self.original, name)


class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname != "torch.distributed":
            return None
        # Delegate to the remaining import hooks; retain their normal ordering.
        later = False
        for finder in list(sys.meta_path):
            if finder is self:
                later = True
                continue
            if later and hasattr(finder, "find_spec"):
                spec = finder.find_spec(fullname, path, target)
                if spec is not None:
                    if spec.loader is not None and hasattr(spec.loader, "exec_module"):
                        spec.loader = Loader(spec.loader)
                    return spec
        return None


def install():
    if "torch.distributed" in sys.modules:
        patch(sys.modules["torch.distributed"])
    else:
        sys.meta_path.insert(0, Finder())
    emit({"event": "probe_bootstrap", "executable": sys.executable})
