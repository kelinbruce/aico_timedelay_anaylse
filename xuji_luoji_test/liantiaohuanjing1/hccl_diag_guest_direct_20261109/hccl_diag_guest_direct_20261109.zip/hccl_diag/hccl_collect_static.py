#!/usr/bin/env python3
"""Read-only Linux host/guest/container inventory; no torch import or NPU workload.

python3 hccl_collect_static.py --layer guest --label env1_48 --out /tmp/hccl48/guest
Host: add --domain INSTANCE_NAME. Guest with Docker: optionally add --container vm_test.
Direct installation in the guest: use --layer guest without --container.
Missing commands, unsupported queries and permissions are recorded, not hidden.
"""
import argparse
import datetime
import glob
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

from hccl_runtime_snapshot import ENV_KEYS


def read_file(path):
    try:
        return Path(path).read_text(errors="replace")
    except OSError as exc:
        return {"error": str(exc)}


def run(argv, timeout=20):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, errors="replace", timeout=timeout)
        return {"argv": argv, "rc": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"argv": argv, "error": str(exc)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--layer", choices=["host", "guest", "container"], required=True)
    ap.add_argument("--label", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--domain", help="libvirt domain on the physical host")
    ap.add_argument("--container", help="Docker container name on the guest")
    ap.add_argument("--device-ids", nargs="+", type=int, default=list(range(8)))
    ap.add_argument("--chip-id", type=int, default=0)
    ap.add_argument("--source-root", action="append", default=[], help="Optional vllm/vllm-ascend checkout root")
    args = ap.parse_args()
    if platform.system() != "Linux":
        ap.error("Run on Linux in the specified layer.")
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / "static.json").exists():
        ap.error("Output already contains static.json; choose a new directory.")
    data = {"label": args.label, "layer": args.layer,
            "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "hostname": platform.node(), "python": sys.executable,
            "environment_scope": "Collector shell only, not worker effective environment.",
            "environment": {k: v for k, v in os.environ.items() if k.startswith("HCCL_") or k in ENV_KEYS},
            "commands": [], "files": {}, "pci": [], "packages": {}, "sources": {}}
    commands = [["uname", "-a"], ["lscpu"], ["numactl", "--hardware"],
                ["lspci", "-Dnn"], ["lspci", "-tv"], ["npu-smi", "info"], ["npu-smi", "info", "-m"]]
    if args.layer == "host":
        commands += [["npu-smi", "info", "-t", "topo"]]
    for dev in args.device_ids:
        commands += [["npu-smi", "info", "-t", "board", "-i", str(dev), "-c", str(args.chip_id)]]
        if args.layer == "host":
            commands += [["npu-smi", "info", "-t", "hccs", "-i", str(dev), "-c", str(args.chip_id)]]
    if args.layer == "host" and args.domain:
        for tail in [["domuuid"], ["dominfo"], ["dumpxml"], ["vcpupin"], ["numatune"]]:
            commands.append(["virsh", tail[0], args.domain])
        commands.append(["virsh", "dumpxml", args.domain, "--inactive"])
    if args.layer == "guest" and args.container:
        # Deliberately omit container Env: it may contain unrelated credentials.
        fmt = '{"Id":{{json .Id}},"Image":{{json .Image}},"ImageName":{{json .Config.Image}},"Mounts":{{json .Mounts}},"CpusetCpus":{{json .HostConfig.CpusetCpus}},"CpusetMems":{{json .HostConfig.CpusetMems}},"Devices":{{json .HostConfig.Devices}},"PidMode":{{json .HostConfig.PidMode}},"Privileged":{{json .HostConfig.Privileged}}}'
        commands.append(["docker", "inspect", "--format", fmt, args.container])
    for cmd in commands:
        print("Collecting:", " ".join(cmd), file=sys.stderr, flush=True)
        data["commands"].append(run(cmd))
    paths = ["/proc/cmdline", "/proc/meminfo", "/proc/self/status", "/proc/self/cgroup",
             "/sys/devices/system/cpu/online", "/sys/devices/system/cpu/isolated",
             "/sys/devices/system/cpu/nohz_full", "/sys/devices/system/node/online",
             "/usr/local/Ascend/driver/version.info", "/usr/local/Ascend/driver/build.info"]
    for pattern in ["/sys/devices/system/node/node*/cpulist", "/sys/devices/system/node/node*/distance",
                    "/usr/local/Ascend/ascend-toolkit/*/*/ascend_toolkit_install.info",
                    "/usr/local/Ascend/ascend-toolkit/*/version.cfg", "/usr/local/Ascend/cann/*/version.cfg",
                    "/usr/local/Ascend/*/version.cfg", "/usr/local/Ascend/*/version.info"]:
        paths += glob.glob(pattern)
    for path in sorted(set(paths)):
        data["files"][path] = read_file(path)
    for pci in sorted(Path("/sys/bus/pci/devices").glob("*")):
        entry = {"bdf": pci.name, "sysfs_path": str(pci.resolve())}
        for field in ["vendor", "device", "class", "numa_node", "local_cpulist", "current_link_speed", "current_link_width", "max_link_speed", "max_link_width"]:
            if (pci / field).exists():
                entry[field] = read_file(pci / field)
        for field in ["driver", "iommu_group"]:
            entry[field] = str((pci / field).resolve()) if (pci / field).exists() else None
        if str(entry.get("vendor", "")).strip() == "0x19e5":
            entry["lspci_verbose"] = run(["lspci", "-Dvvnn", "-s", pci.name])
        data["pci"].append(entry)
    roots = [Path(p) for p in args.source_root]
    for package in ["torch", "torch-npu", "vllm", "vllm-ascend"]:
        try:
            dist = importlib.metadata.distribution(package)
            direct = dist.read_text("direct_url.json")
            data["packages"][package] = {"version": dist.version, "metadata_location": str(dist.locate_file("")), "direct_url": json.loads(direct) if direct else None}
            roots.append(Path(dist.locate_file("")))
        except (importlib.metadata.PackageNotFoundError, OSError, ValueError) as exc:
            data["packages"][package] = {"error": str(exc)}
    roots += [Path("/vllm-workspace/vllm"), Path("/vllm-workspace/vllm-ascend")]
    selected = ["vllm/config/parallel.py", "vllm/distributed/parallel_state.py",
                "vllm_ascend/utils.py", "vllm_ascend/cpu_binding.py", "vllm_ascend/platform.py",
                "vllm_ascend/distributed/parallel_state.py", "vllm_ascend/worker/worker.py",
                "vllm_ascend/compilation/compiler_interface.py"]
    for root in sorted(set(roots)):
        if (root / ".git").exists():
            data["commands"].append(run(["git", "-C", str(root), "rev-parse", "HEAD"]))
            data["commands"].append(run(["git", "-C", str(root), "diff", "--", *selected]))
        for rel in selected:
            path = root / rel
            if path.is_file() and str(path.resolve()) not in data["sources"]:
                try:
                    content = path.read_bytes()
                    data["sources"][str(path.resolve())] = {"sha256": hashlib.sha256(content).hexdigest(), "text": content.decode(errors="replace")}
                except OSError as exc:
                    data["sources"][str(path.resolve())] = {"error": str(exc)}
    (out / "static.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(str(out / "static.json"))


if __name__ == "__main__":
    main()
