"""Opt-in process-group diagnostics. Does not import torch early."""
import os
if os.environ.get("HCCL_DIAG_PG_DIR"):
    try:
        from hccl_pg_capture import install
        install()
    except Exception as exc:
        import sys
        print("HCCL PG diagnostic hook failed: " + str(exc), file=sys.stderr)
