#!/usr/bin/env python3
"""Read HCCL worker state in the inference container; JSON goes to stdout.

Run after startup and at least one representative inference request:
    python3 hccl_runtime_snapshot.py > runtime.json
Explicit container-local PIDs can be supplied with --pids 123 456.
Uses only Python's standard library. Does not import torch or initialize NPUs.
"""

import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys


ENV_KEYS = {
    "ASCEND_VISIBLE_DEVICES", "ASCEND_RT_VISIBLE_DEVICES", "ASCEND_DEVICE_ID",
    "ASCEND_HOME_PATH", "ASCEND_OPP_PATH", "LD_LIBRARY_PATH", "LD_PRELOAD",
    "ASCEND_GLOBAL_LOG_LEVEL", "ASCEND_MODULE_LOG_LEVEL", "ASCEND_PROCESS_LOG_PATH",
    "ASCEND_SLOG_PRINT_TO_STDOUT", "ASCEND_WORK_PATH", "ASCEND_HOST_LOG_FILE_NUM",
    "TASK_QUEUE_ENABLE", "PYTHONPATH", "RANK", "LOCAL_RANK", "WORLD_SIZE",
    "VLLM_USE_V2_MODEL_RUNNER", "VLLM_ASCEND_APPLY_DSV4_PATCH",
    "OMP_NUM_THREADS", "OMP_PROC_BIND", "LOCAL_ASCEND_CPU_POOLS",
    "ASCEND_LAUNCH_BLOCKING", "VLLM_BATCH_INVARIANT",
}
LIB_RE = re.compile(r"^lib(?:hccl|hcomm|hcom|torch_npu|ascendcl|ascend_hal|ascendalog|jemalloc|opapi).*\.so")
HASH_CACHE = {}


def text_file(path):
    return Path(path).read_text(errors="replace")


def start_ticks(proc):
    # Field 22; comm may contain spaces and parentheses.
    return text_file(proc / "stat").rsplit(")", 1)[1].split()[19]


def library_info(proc, mapped_path, map_device, map_inode):
    result = {"path": mapped_path, "map_device": map_device, "map_inode": map_inode}
    if mapped_path.endswith(" (deleted)"):
        result["error"] = "Deleted mapping: cannot establish loaded bytes from disk."
        return result
    disk_path = proc / "root" / mapped_path.lstrip("/")
    try:
        with disk_path.open("rb") as stream:
            before = os.fstat(stream.fileno())
            dev = tuple(int(x, 16) for x in map_device.split(":"))
            if (os.major(before.st_dev), os.minor(before.st_dev)) != dev or before.st_ino != map_inode:
                raise ValueError("On-disk file no longer matches the mapped device/inode")
            key = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
            if key not in HASH_CACHE:
                digest = hashlib.sha256()
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
                after = os.fstat(stream.fileno())
                if key != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
                    raise ValueError("Library changed while hashing")
                HASH_CACHE[key] = digest.hexdigest()
            result.update(sha256=HASH_CACHE[key], size_bytes=before.st_size)
    except (OSError, ValueError) as exc:
        result["error"] = str(exc)
    return result


def worker_snapshot(pid):
    proc = Path("/proc") / str(pid)
    result = {"pid": pid}
    try:
        before = start_ticks(proc)
        result["comm"] = text_file(proc / "comm").strip()
        result["executable"] = os.readlink(proc / "exe")
        status = dict(line.split(":", 1) for line in text_file(proc / "status").splitlines() if ":" in line)
        result["status"] = {k: status[k].strip() for k in ("Name", "NSpid", "Cpus_allowed_list", "Mems_allowed_list") if k in status}
        env = {}
        for entry in (proc / "environ").read_bytes().split(b"\0"):
            key, sep, value = entry.partition(b"=")
            name = key.decode(errors="replace")
            if sep and (name.startswith("HCCL_") or name in ENV_KEYS):
                env[name] = value.decode(errors="replace")
        result["exec_environment_subset"] = env
        result["threads"] = []
        for task in sorted((proc / "task").glob("[0-9]*")):
            try:
                fields = dict(line.split(":", 1) for line in text_file(task / "status").splitlines() if ":" in line)
                result["threads"].append({"tid": int(task.name), **{k: fields[k].strip() for k in ("Name", "Cpus_allowed_list", "Mems_allowed_list") if k in fields}})
            except OSError:
                pass
        mappings = set()
        for line in text_file(proc / "maps").splitlines():
            fields = line.split(maxsplit=5)
            if len(fields) == 6 and fields[5].startswith("/") and LIB_RE.match(Path(fields[5]).name):
                mappings.add((fields[5], fields[3], int(fields[4])))
        result["loaded_libraries"] = [library_info(proc, *entry) for entry in sorted(mappings)]
        result["start_ticks"] = before
        result["pid_stable_during_capture"] = before == start_ticks(proc)
    except (OSError, ValueError, IndexError) as exc:
        result["error"] = str(exc)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--pids", nargs="+", type=int, help="Container-local worker PIDs; otherwise discover VLLM::Worker processes")
    args = parser.parse_args()
    if not Path("/proc/self/status").exists():
        parser.error("Run inside the Linux inference container, in the workers' PID namespace.")
    pids = args.pids or []
    if not args.pids:
        for proc in Path("/proc").glob("[0-9]*"):
            try:
                if text_file(proc / "comm").strip().startswith("VLLM::Worker"):
                    pids.append(int(proc.name))
            except OSError:
                pass
    result = {
        "captured_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "hostname": socket.gethostname(),
        "kernel": os.uname().release,
        "collector_python": sys.executable,
        "worker_count": len(pids),
        "notes": [
            "/proc/PID/environ is exec-time environment evidence; later setenv changes or communicator configuration can override it. Use HCCL logs to establish effective mode.",
            "Package versions below belong to the collector's Python environment; loaded library paths and hashes are taken from the actual workers.",
            "Missing, deleted or changed libraries are reported, not treated as matching. CPU scheduling latency and device transfer performance are not measured.",
        ],
        "workers": [worker_snapshot(pid) for pid in sorted(set(pids))],
        "collector_package_versions": {},
    }
    for package in ("torch", "torch-npu", "vllm", "vllm-ascend"):
        try:
            result["collector_package_versions"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            result["collector_package_versions"][package] = None
    try:
        completed = subprocess.run(["npu-smi", "info"], capture_output=True, text=True, timeout=20)
        result["npu_smi_info"] = {"returncode": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr}
    except (OSError, subprocess.TimeoutExpired) as exc:
        result["npu_smi_info"] = {"error": str(exc)}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if pids else 2


if __name__ == "__main__":
    raise SystemExit(main())
