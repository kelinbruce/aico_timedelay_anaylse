"""Functional checks without torch/NPU: deferred hook, calls, errors and launcher."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest

HERE = Path(__file__).resolve().parent


class DiagnosticsTests(unittest.TestCase):
    def test_deferred_probe_preserves_calls_options_and_errors(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            fake = root / "fake"
            package = fake / "torch" / "distributed"
            package.mkdir(parents=True)
            (fake / "torch" / "__init__.py").write_text("def are_deterministic_algorithms_enabled(): return True\n")
            (package / "__init__.py").write_text(textwrap.dedent('''
                import types
                group = types.SimpleNamespace(WORLD=None)
                def init_process_group(backend=None, pg_options=None):
                    group.WORLD = types.SimpleNamespace(options=pg_options)
                def new_group(ranks=None, backend=None, pg_options=None, group_desc=None):
                    if group_desc == 'fail':
                        raise RuntimeError('original failure')
                    return (ranks, backend, pg_options, group_desc)
            '''))
            env = dict(os.environ, PYTHONPATH=str(HERE / "pg_probe") + os.pathsep + str(fake), HCCL_DIAG_PG_DIR=str(root / "pg"), HCCL_OP_EXPANSION_MODE="AIV")
            code = textwrap.dedent('''
                import sys, types
                assert 'torch' not in sys.modules, 'probe eagerly imported torch'
                import torch.distributed as dist
                opts = types.SimpleNamespace(hccl_config={'hcclOpExpansionMode':1, 'group_name':'test'})
                assert dist.init_process_group('hccl', opts) is None
                result = dist.new_group([0,1], 'hccl', opts, 'tp')
                assert result[2] is opts and result[0] == [0,1] and result[3] == 'tp'
                assert opts.hccl_config == {'hcclOpExpansionMode':1, 'group_name':'test'}
                try:
                    dist.new_group(group_desc='fail')
                except RuntimeError as exc:
                    assert str(exc) == 'original failure'
                else:
                    raise AssertionError('original exception lost')
            ''')
            result = subprocess.run([sys.executable, "-c", code], env=env, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            events = [json.loads(line) for p in (root / "pg").glob("*.jsonl") for line in p.read_text().splitlines()]
            self.assertEqual(sum(e["event"] == "hook_installed" for e in events), 1)
            before = [e for e in events if e["event"] == "before"]
            self.assertEqual(len(before), 3)
            self.assertEqual(before[1]["pg_options"]["hccl_config"]["hcclOpExpansionMode"], 1)
            self.assertEqual(before[1]["environment_at_call"]["HCCL_OP_EXPANSION_MODE"], "AIV")
            self.assertTrue(before[1]["torch_deterministic_algorithms"])
            self.assertEqual(sum(e["event"] == "call_error" for e in events), 1)
            self.assertFalse(any(e["event"] == "inspection_error" for e in events))

    def test_wrapper_preserves_exit_args_and_mode(self):
        with tempfile.TemporaryDirectory(prefix="hccl smoke ") as td:
            root = Path(td)
            start = root / "start mock.sh"
            start.write_text('''#!/usr/bin/env bash
test "$1" = 'argument with space' || exit 44
test "$HCCL_OP_EXPANSION_MODE" = AIV || exit 45
test "$ASCEND_MODULE_LOG_LEVEL" = HCCL=0 || exit 46
printf 'mock service output\\n'
exit 7
''')
            out = root / "result"
            env = dict(os.environ, HCCL_OP_EXPANSION_MODE="AIV", HCCL_DIAG_PG_PROBE="0")
            argv = ["bash", str(HERE / "run_hccl_logged.sh"), str(out), str(start), "argument with space"]
            r = subprocess.run(argv, env=env, capture_output=True, text=True)
            self.assertEqual(r.returncode, 7, r.stderr)
            self.assertIn("mock service output", (out / "startup.log").read_text())
            self.assertIn("startup_exit=7", (out / "exit_status.txt").read_text())
            again = subprocess.run(argv, env=env, capture_output=True, text=True)
            self.assertEqual(again.returncode, 2)
            self.assertIn("already exists", again.stderr)

    def test_wrapper_injects_probe_and_refuses_existing_sitecustomize(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            fake = root / "fake"
            (fake / "torch" / "distributed").mkdir(parents=True)
            (fake / "torch" / "__init__.py").write_text("")
            (fake / "torch" / "distributed" / "__init__.py").write_text("def new_group(backend=None): return backend\n")
            start = root / "start.sh"
            start.write_text("python3 -c \"import torch.distributed as d; assert d.new_group(backend='hccl') == 'hccl'\"\n")
            env = dict(os.environ, PYTHONPATH=str(fake), HCCL_DIAG_PG_PROBE="1")
            out = root / "out"
            r = subprocess.run(["bash", str(HERE / "run_hccl_logged.sh"), str(out), str(start)], env=env, capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stderr)
            events = [json.loads(line) for p in (out / "pg").glob("*.jsonl") for line in p.read_text().splitlines()]
            self.assertTrue(any(e["event"] == "before" and e["api"] == "new_group" for e in events))
            (fake / "sitecustomize.py").write_text("# Existing site customization must not be replaced.\n")
            blocked = subprocess.run(["bash", str(HERE / "run_hccl_logged.sh"), str(root / "blocked"), str(start)], env=env, capture_output=True, text=True)
            self.assertEqual(blocked.returncode, 2)
            self.assertIn("Existing sitecustomize", blocked.stderr)


if __name__ == "__main__":
    unittest.main()
