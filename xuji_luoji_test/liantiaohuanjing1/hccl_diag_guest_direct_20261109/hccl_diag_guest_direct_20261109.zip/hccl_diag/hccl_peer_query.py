#!/usr/bin/env python3
"""Query NPU peer-access capability in a separate Python process, while idle.

Imports torch/torch_npu and may initialize the runtime. Does not allocate test
tensors, enable peer access, change device state, or run a bandwidth test.
Capability is not proof of the transport/algorithm actually selected by HCCL.
"""
import datetime
import json
import os
import sys
from hccl_runtime_snapshot import worker_snapshot


def main():
    data = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "python": sys.executable,
            "notes": ["Device IDs below are process-local logical IDs; compare visibility and npu-smi mappings.",
                      "True means advertised peer access, not HCCS transport or measured bandwidth.",
                      "Unsupported/failed queries are errors, never converted to False."],
            "matrix": []}
    rc = 0
    try:
        import torch
        import torch_npu
        data["torch"] = torch.__version__
        data["torch_npu"] = torch_npu.__version__
        count = torch.npu.device_count()
        data["device_count"] = count
        if count != 8:
            data["warning"] = "Expected 8 visible NPUs for this investigation; verify visibility before comparing."
            rc = 2
        for i in range(count):
            row = []
            for j in range(count):
                if i == j:
                    row.append(None)
                    continue
                try:
                    row.append(bool(torch.npu.can_device_access_peer(i, j)))
                except Exception as exc:
                    row.append({"error": str(exc)})
                    rc = 2
            data["matrix"].append(row)
    except Exception as exc:
        data["error"] = str(exc)
        rc = 2
    data["query_process"] = worker_snapshot(os.getpid())
    print(json.dumps(data, ensure_ascii=False, indent=2))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
